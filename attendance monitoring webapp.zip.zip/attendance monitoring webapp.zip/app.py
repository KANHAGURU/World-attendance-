from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Create database and tables if not exist
def init_db():
    conn = sqlite3.connect('attendance.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            role TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            timestamp TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    ''')
    # Default admin
    c.execute("INSERT OR IGNORE INTO users (username, password, role) VALUES (?, ?, ?)", ('admin', 'admin', 'admin'))
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    conn = sqlite3.connect('attendance.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    user = c.fetchone()
    conn.close()
    if user:
        session['user_id'] = user[0]
        session['username'] = user[1]
        session['role'] = user[3]
        if user[3] == 'admin':
            return redirect('/admin')
        else:
            return redirect('/user')
    else:
        return "Invalid credentials"

@app.route('/admin')
def admin_dashboard():
    if 'role' in session and session['role'] == 'admin':
        conn = sqlite3.connect('attendance.db')
        c = conn.cursor()
        c.execute('''
            SELECT a.id, u.username, a.timestamp 
            FROM attendance a
            JOIN users u ON a.user_id = u.id
            ORDER BY a.timestamp DESC
        ''')
        data = c.fetchall()
        conn.close()
        return render_template('admin.html', records=data)
    return redirect('/')

@app.route('/user')
def user_dashboard():
    if 'role' in session and session['role'] == 'user':
        return render_template('user.html', username=session['username'])
    return redirect('/')

@app.route('/mark_attendance')
def mark_attendance():
    if 'user_id' in session:
        conn = sqlite3.connect('attendance.db')
        c = conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("INSERT INTO attendance (user_id, timestamp) VALUES (?, ?)", (session['user_id'], now))
        conn.commit()
        conn.close()
        return "Attendance marked successfully!"
    return redirect('/')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)